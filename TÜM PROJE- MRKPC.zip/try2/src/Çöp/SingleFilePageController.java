package Çöp;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.PieChart;
import org.knowm.xchart.RadarChart;

import java.net.URL;
import java.util.ResourceBundle;

public class SingleFilePageController implements Initializable {
    @FXML
    private RadarChart radar;

    @FXML
    private PieChart pie;

    @FXML
    private CategoryChart bar;


    public void initialize(URL location, ResourceBundle resources) {



    }
}
