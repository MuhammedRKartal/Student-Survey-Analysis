public class Subsection {
    public String text;
    public double average;
    public double stddev;
    public double na;
    public double no;
    public double one;
    public double two;
    public double three;
    public double four;
    public double five;
    public double universityAverage;

    Subsection(){}

}