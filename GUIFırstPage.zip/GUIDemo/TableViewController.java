package GUIDemo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TableViewController  implements Initializable {

    List<File>filesArray;


    //These are mandatory to use fxml
    @FXML
    private TableView<Course> courseTable;

    @FXML
    public TableColumn<Course, String> courseCode;

    @FXML
    public TableColumn<Course,String> section;

    @FXML
    public TableColumn<Course,String> year;

    @FXML
    public TableColumn<Course,String> term;


    @Override
    //These are mandatory
    public void initialize(URL location, ResourceBundle resources) {
        //set up table columns
        courseCode.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        section.setCellValueFactory(new PropertyValueFactory<>("section"));
        year.setCellValueFactory(new PropertyValueFactory<>("year"));
        term.setCellValueFactory(new PropertyValueFactory<>("term"));


    }

    // Adding chosen files to the table on first screen.
    public ObservableList<Course> getCourse(){
        //Must be ObservableList type
        ObservableList<Course> courses = FXCollections.observableArrayList();
//        courses.add(new Course("COMP103","1","2015","2"));
//        courses.add(new Course("COMP101","2","2016","3"));
//        courses.add(new Course("COMP101","3","2011","34"));
        ArrayList<File> tempFileArray= new ArrayList<>();
        for(int i = 0; i<filesArray.size(); i++){
            tempFileArray.add(filesArray.get(i));
        }

        for (File x:tempFileArray) {
            System.out.println(x.getName());
        }
//        if(tempFileArray.size()==0){
//            System.out.println("Please select file(s)");
//        }
        try{
            for (int i = 0; i < tempFileArray.size(); i++) {
                String name = tempFileArray.get(i).getName();
                String temp = name.split("x")[0];
                try{
                    String[] nameParts = temp.split("_");
                    String courseCode = nameParts[0];
                    String section = nameParts[1];
                    String year = nameParts[2];
                    String term = nameParts[3];
                    Course oneCourse = new Course(courseCode, section, year, term);
                    courses.add(oneCourse);
                }
                catch (Exception exception){
                    System.out.println("Please enter file name on CourseCode_Section_Year_Term.xlsx format");
                }

            }
        }
        catch (Exception exception){
            System.out.println(exception);
        }


        return courses;
    }

    //If chosen files arrays lenght == 1 go to singleFileScreen.fxml
    //if length>1 go to multiFileScreen.fxml
    public void changeScreenButtonPushed(ActionEvent event) throws IOException{
        /*
        if (filesArray.size()==0){
            //If no file is chosen
            System.out.println("Please select a file");
        }
        else if(filesArray.size() == 1){
            //For single file
            Parent screenParent = FXMLLoader.load(getClass().getResource("singleFileScreen.fxml"));
            Scene secondScreenScene = new Scene(screenParent);
        }
        else{
            //For multifile
            Parent screenParent = FXMLLoader.load(getClass().getResource("multiFileScreen.fxml"));
            Scene secondScreenScene = new Scene(screenParent);
        }
        */
        Parent screenParent = FXMLLoader.load(getClass().getResource("singleFileScreen.fxml"));
        Scene secondScreenScene = new Scene(screenParent);

        Stage window = (Stage)(((Node)event.getSource()).getScene().getWindow());
        window.setScene(secondScreenScene);
        window.show();
    }

    public void choseFileButtonPushed(ActionEvent event) throws IOException{
        FileChooser fileChooser = new FileChooser();

        fileChooser.setTitle("Select File Dialog");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Files","*.xlsx"));
        filesArray =  fileChooser.showOpenMultipleDialog(null);
//        for (File x:filesArray) {
//            System.out.println(x.getName());
//        }

        //load dummy data
        courseTable.setItems(getCourse());
    }


}
